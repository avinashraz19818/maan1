<?php
/**
 * Optional MySQL override file.
 *
 * Is file ka naam badal kar  dw-db-config.php  rakhiye aur site ki root
 * (public_html) me upload kar dijiye. api/_core/config.php ise automatically
 * padh lega — is tarah future updates me aapke credentials overwrite nahi honge.
 *
 * cPanel > MySQL Databases me jo DB name / user / password banaya hai wahi yaha likhiye.
 */
return [
    'DB_HOST' => 'localhost',
    'DB_NAME' => 'youruser_dbname',
    'DB_USER' => 'youruser_dbuser',
    'DB_PASS' => 'yourpassword',
];

<?php
/**
 * Accept a local Deepanshu JWT or a remote Veergame JWT payload
 * so /pay cashiers can open after remote login.
 */
if (!function_exists('pay_b64url_decode')) {
    function pay_b64url_decode(string $str): string
    {
        $str = strtr($str, '-_', '+/');
        $pad = strlen($str) % 4;
        if ($pad) {
            $str .= str_repeat('=', 4 - $pad);
        }
        $out = base64_decode($str, true);
        return $out === false ? (string) base64_decode($str) : $out;
    }
}

if (!function_exists('pay_request_jwt')) {
    function pay_request_jwt(): string
    {
        if (function_exists('dmg_request_jwt_token')) {
            $t = trim((string) dmg_request_jwt_token());
            if ($t !== '') {
                return $t;
            }
        }
        foreach (['sign', 'token', 'jwt'] as $k) {
            $v = trim((string) ($_GET[$k] ?? $_POST[$k] ?? ''));
            if ($v !== '' && substr_count($v, '.') === 2) {
                return preg_replace('/^Bearer\s+/i', '', $v);
            }
        }
        return '';
    }
}

if (!function_exists('pay_jwt_payload')) {
    function pay_jwt_payload(?string $token = null): array
    {
        $token = $token === null ? pay_request_jwt() : trim((string) $token);
        $token = preg_replace('/^Bearer\s+/i', '', $token);
        if ($token === '' || substr_count($token, '.') < 2) {
            return [];
        }
        $parts = explode('.', $token);
        $raw = pay_b64url_decode($parts[1] ?? '');
        $payload = json_decode($raw, true);
        return is_array($payload) ? $payload : [];
    }
}

if (!function_exists('pay_jwt_uid_any')) {
    function pay_jwt_uid_any(?string $token = null): int
    {
        if (function_exists('dmg_jwt_uid')) {
            $local = (int) dmg_jwt_uid($token);
            if ($local > 0) {
                return $local;
            }
        }
        $p = pay_jwt_payload($token);
        foreach (['id', 'userId', 'UserId', 'userid', 'uid', 'Id'] as $k) {
            if (isset($p[$k]) && (int) $p[$k] > 0) {
                return (int) $p[$k];
            }
        }
        return 0;
    }
}

if (!function_exists('pay_accept_uid_jwt')) {
    function pay_accept_uid_jwt(int $uid): bool
    {
        if ($uid <= 0) {
            return false;
        }
        if (function_exists('dmg_require_uid_jwt') && dmg_require_uid_jwt($uid)) {
            return true;
        }
        return pay_jwt_uid_any() === $uid;
    }
}

if (!function_exists('pay_ensure_local_player')) {
    function pay_ensure_local_player($conn, int $uid): bool
    {
        if (!$conn instanceof mysqli || $uid <= 0) {
            return false;
        }

        $stmt = $conn->prepare('SELECT id, mobile FROM shonu_subjects WHERE id=? LIMIT 1');
        if (!$stmt) {
            return false;
        }
        $stmt->bind_param('i', $uid);
        $stmt->execute();
        $res = $stmt->get_result();
        $row = $res ? $res->fetch_assoc() : null;
        $stmt->close();

        $now = date('Y-m-d H:i:s');
        $payload = pay_jwt_payload();
        $mobile = '';
        foreach (['mobile', 'username', 'phone', 'userName'] as $k) {
            if (!empty($payload[$k])) {
                $mobile = preg_replace('/\D+/', '', (string) $payload[$k]);
                break;
            }
        }
        if ($mobile === '') {
            $mobile = '9' . str_pad((string) $uid, 9, '0', STR_PAD_LEFT);
            if (strlen($mobile) > 15) {
                $mobile = substr($mobile, 0, 15);
            }
        }

        if ($row) {
            $have = trim((string) ($row['mobile'] ?? ''));
            if ($have === '') {
                $up = $conn->prepare('UPDATE shonu_subjects SET mobile=? WHERE id=? LIMIT 1');
                if ($up) {
                    $up->bind_param('si', $mobile, $uid);
                    $up->execute();
                    $up->close();
                }
            }
        } else {
            $nick = 'Member' . $uid;
            $own = 'VG' . $uid;
            $hash = function_exists('dmg_password_hash_store')
                ? dmg_password_hash_store(bin2hex(random_bytes(8)))
                : password_hash(bin2hex(random_bytes(8)), PASSWORD_DEFAULT);
            $ins = $conn->prepare(
                'INSERT INTO shonu_subjects
                    (id, mobile, email, password, code, owncode, privacy, status, createdate, ip, pwd, codechorkamukala)
                 VALUES (?, ?, \'\', ?, \'\', ?, \'on\', \'1\', ?, \'\', \'\', ?)'
            );
            if (!$ins) {
                $ins = $conn->prepare(
                    'INSERT INTO shonu_subjects (id, mobile, password, status, createdate, codechorkamukala)
                     VALUES (?, ?, ?, \'1\', ?, ?)'
                );
                if (!$ins) {
                    return false;
                }
                $ins->bind_param('issss', $uid, $mobile, $hash, $now, $nick);
            } else {
                $ins->bind_param('isssss', $uid, $mobile, $hash, $own, $now, $nick);
            }
            if (!$ins->execute()) {
                $ins->close();
                $again = $conn->prepare('SELECT id FROM shonu_subjects WHERE id=? LIMIT 1');
                if (!$again) {
                    return false;
                }
                $again->bind_param('i', $uid);
                $again->execute();
                $got = $again->get_result();
                $ok = $got && $got->fetch_assoc();
                $again->close();
                if (!$ok) {
                    return false;
                }
            } else {
                $ins->close();
            }
        }

        $w = $conn->prepare('SELECT balakedara FROM shonu_kaichila WHERE balakedara=? LIMIT 1');
        if ($w) {
            $bal = (string) $uid;
            $w->bind_param('s', $bal);
            $w->execute();
            $wr = $w->get_result();
            $exists = $wr && $wr->fetch_assoc();
            $w->close();
            if (!$exists) {
                $zero = 0.0;
                $wi = $conn->prepare('INSERT INTO shonu_kaichila (balakedara, motta, dinankavannuracisi) VALUES (?, ?, ?)');
                if ($wi) {
                    $wi->bind_param('sds', $bal, $zero, $now);
                    $wi->execute();
                    $wi->close();
                }
            }
        }

        return true;
    }
}
